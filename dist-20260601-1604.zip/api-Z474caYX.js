const t="".trim().replace(/\/+$/,"");function r(r){if(!r)return t;if(/^https?:\/\//i.test(r))return r;const e=r.startsWith("/")?r:`/${r}`;return`${t}${e}`}export{t as API_BASE,r as apiUrl};
